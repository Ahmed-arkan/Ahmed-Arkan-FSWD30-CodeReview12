<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 *
 * @package ahmed_first_project
 */

?>

	</div><!-- #content -->

  <footer class="blog-footer">
     <p> &copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?> </p>
     <p>
       <a href="#">Back to top</a>
     </p>
   </footer>
   <?php wp_footer(); ?>

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
   <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 </body>
</html>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
