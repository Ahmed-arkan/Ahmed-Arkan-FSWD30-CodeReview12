<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ahmed_first_project
 */

get_header(); ?>


 </div>
   <div class="con" style="width: 100%;">
     <div class="jumbotro">
    <div class="namee">
      <h1> Blog </h1> 
       <h4 class="blog-title"><?php bloginfo('name'); ?></h4>
       <p class="lead blog-description"> <?php bloginfo('description'); ?></p>
     </div>
 
  </div>
</div>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>


<div class="foot">
  <div class="conta">
    <div class="item">
      <span> <i class="fab fa-facebook-f fa-2x"></i></span><span class="names"> - facebook</span>
      <span> <i class="fab fa-instagram fa-2x"></i></span><span class="names"> - instagram</span>
      <span> <i class="fab fa-google-plus-g fa-2x"></i></span><span class="names"> - google +</span>
      <span> <i class="fab fa-twitter fa-2x"></i></span><span class="names"> - twitter</span>
      <span> <i class="fas fa-heart fa-2x"></i></span><span class="names"> - blogloven</span>
      <span> <i class="fab fa-youtube fa-2x"></i></span><span class="names"> - youtube</span>
    </div>
  </div>
</div>

<?php
get_footer();
?>
